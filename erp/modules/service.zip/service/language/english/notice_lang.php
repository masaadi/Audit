<?php
    $lang['notice_board'] = "NOTICE BOARD";
    $lang['all_notice'] = "ALL NOTICE";
    $lang['notification'] = "Notifications";

    $lang['application_checklist'] = "APPLICATION CHECKLIST";
    $lang['view'] = "View";
    $lang['title'] = "Title";
    $lang['notice'] = "Notice";
    $lang['description'] = "Description";
    $lang['no_data_found'] = "No data found ";
    $lang['back'] = "Back";
    $lang['date'] = "Date";
    $lang['download'] = "Download";

?>