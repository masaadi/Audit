<?php
$lang['add_new'] = "Add New";
$lang['sl'] = 'SL';
$lang['name'] = 'Name';
$lang['action'] = 'Action';
$lang['view'] = 'View';
$lang['edit'] = 'Edit';
$lang['delete'] = 'Delete';
$lang['no_data_found'] = 'No data found';
$lang['search'] = 'Search';
$lang['save'] = 'Save';
$lang['update'] = 'Update';


$lang['suggestion'] = 'Suggestion';
$lang['review'] = 'Review';
$lang['rate_this_system'] = 'Rate This System';
$lang['write_something'] = "Write somethig......";
$lang['write_your_suggestion'] = "Write your suggestion";
$lang['view_all'] = "View All";
$lang['show'] = "Show";
$lang['star'] = "Star";
$lang['review_details'] = "Review Detalis";
$lang['feedback'] = "Feedback";
$lang['completed'] = "Completed";
$lang['ongoing'] = "Ongoing";