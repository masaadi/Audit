<?php
$lang['sl'] = "SL";
$lang['OG_OFFICE_NAME'] = "Office Name";
$lang['OG_PARENT_OFFICE'] = "Parent Office";
$lang['OG_EMP_NO'] = "Employee No";
$lang['OG_STATUS'] = "Status";
$lang['actions'] = "Actions";

?>