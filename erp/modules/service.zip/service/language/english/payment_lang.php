<?php 

$lang['add_payment'] = "Add Payment";
$lang['payment_list'] = "Payment List";

$lang['fiscal_years'] = "Fiscal Years";
$lang['amount'] = "Amount";
$lang['payment_date'] = "Payment Date";


$lang['pool_name'] = "Pool Name";
$lang['join_job_Information'] = "Joining Job Information";
$lang['curr_job_Information'] = "Current Job Information";
$lang['job_info'] = "Job Information";
$lang['other_Information'] = "Other Information";
$lang['employee_type'] = "Employee Type";
$lang['employee_class'] = "Employee Class";
$lang['prl_date'] = "Prl Date";
$lang['res_details'] = "Responsibility Details";
$lang['super_designation_name'] = " accounts office Controlling Officer Designation: ";
$lang['super_name'] = "Controlling Officer Name";
$lang['super_wing_name'] = "Controlling Officer Wing";
$lang['login_id'] = "Login ID";
$lang['sig_attach'] = "Employee Signature";
$lang['post_status'] = "Promotional Status";
$lang['post_status'] = "Promotional Status";









