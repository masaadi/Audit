<?php
$lang['sl'] = "SL";
$lang['OG_OFFICE_NAME'] = "অফিসের নাম";
$lang['OG_PARENT_OFFICE'] = "মূল কার্যালয়";
$lang['OG_EMP_NO'] = "কর্মী সংখ্যা";
$lang['OG_STATUS'] = "অবস্থা";
$lang['actions'] = "অ্যাকশন";

?>