<?php 

$lang['add_payment'] = "পেমেন্ট যুক্ত করুন";
$lang['payment_list'] = "পেমেন্ট তালিকা";

$lang['fiscal_years'] = "আর্থিক বছর";
$lang['amount'] = "পরিমাণ";
$lang['payment_date'] = "টাকা প্রদানের তারিখ";


$lang['employee_id'] = "কর্মকর্তা আইডি";
$lang['name_of_service'] = "সেবার নাম";
$lang['employee_name'] = "কর্মকর্তার নাম";
$lang['qualification'] = "যোগ্যতা";
$lang['qualification_bn'] = "যোগ্যতা (বাংলা)";
$lang['qualification_details'] = "বিস্তারিত যোগ্যতা";
$lang['qualification_details_bn'] = "বিস্তারিত যোগ্যতা (বাংলা)";
$lang['add_more_extra'] = "অতিরিক্ত সাধারণ যোগ্যতা যোগ করুন (যদি প্রয়োজন হয়)";

