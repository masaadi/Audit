<?php
$lang['add_new'] = "নতুন যুক্ত করুন";
$lang['sl'] = 'ক্রমিক নং';
$lang['name'] = 'নাম';
$lang['action'] = 'কর্ম';
$lang['view'] = 'দেখুন';
$lang['edit'] = 'সম্পাদনা';
$lang['delete'] = 'মুছুন';
$lang['no_data_found'] = 'তথ্য পাওয়া যায়নি।';
$lang['search'] = 'অনুসন্ধান';
$lang['save'] = 'সংরক্ষণ';
$lang['update'] = 'আপডেট';

$lang['suggestion'] = 'পরামর্শ';
$lang['review'] = 'মূল্যায়ন করুন';
$lang['rate_this_system'] = 'এই সিস্টেমটি রেট করুন';
$lang['write_something'] = "কিছু লিখুন......";
$lang['write_your_suggestion'] = "আপনার পরামর্শ লিখুন";
$lang['view_all'] = "সবগুলো দেখুন";
$lang['show'] = "দেখুন";
$lang['star'] = "ষ্টার";
$lang['review_details'] = "পর্যালোচনার বিবরণ";
$lang['feedback'] = "মতামত";
$lang['completed'] = "সমাপ্ত";
$lang['ongoing'] = "চলমান...";