<?php
$lang['notice_board'] = "নোটিস বোর্ড";
$lang['all_notice'] = "সমস্ত নোটিশ";
$lang['notification'] = "বিজ্ঞপ্তি";
$lang['application_checklist'] = "আবেদন চেকলিস্ট";
$lang['view'] = "দেখুন";
$lang['title'] = "শিরোনাম";
$lang['notice'] = "নোটিশ";
$lang['description'] = "বর্ণনা";
$lang['no_data_found'] = "কোন তথ্য পাওয়া যায় নি";
$lang['back'] = "পেছনে যান";
$lang['date'] = "তারিখ";
$lang['download'] = "ডাউনলোড";



?>